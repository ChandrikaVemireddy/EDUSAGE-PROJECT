import React,{useEffect,useMemo,useState} from 'react';
import {createRoot} from 'react-dom/client';
import {LayoutDashboard,Users,FileText,ClipboardCheck,CalendarDays,BarChart3,Bell,Search,ChevronRight,CheckCircle2,Clock3,AlertCircle,MessageCircle,GraduationCap,ArrowLeft,ShieldCheck,Sparkles,Menu,Download,Filter,Plus,MoreHorizontal,Check, X, CircleDot} from 'lucide-react';
import './style.css';

const API='http://localhost:8000/api';
const nav=[['Overview',LayoutDashboard],['Applicants',Users],['Applications',FileText],['Review & Decisions',ClipboardCheck],['Events',CalendarDays],['Analytics',BarChart3]];

function App(){
 const [page,setPage]=useState('Overview'); const [data,setData]=useState(null); const [apps,setApps]=useState([]); const [selected,setSelected]=useState(null); const [search,setSearch]=useState(''); const [toast,setToast]=useState(''); const [mobile,setMobile]=useState(false);
 const load=()=>{fetch(API+'/dashboard').then(r=>r.json()).then(setData);fetch(API+'/applicants').then(r=>r.json()).then(setApps)};
 useEffect(load,[]); useEffect(()=>{if(toast){const t=setTimeout(()=>setToast(''),2400);return()=>clearTimeout(t)}},[toast]);
 const doSearch=(v)=>{setSearch(v);fetch(API+'/applicants?q='+encodeURIComponent(v)).then(r=>r.json()).then(setApps)};
 const openApplicant=async id=>{const r=await fetch(API+`/applicants/${id}`);setSelected(await r.json());setPage('Applicants');window.scrollTo(0,0)};
 const decision=async d=>{if(!selected)return; await fetch(API+`/applicants/${selected.id}/decision`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({decision:d,note:'Reviewed by Admissions Admin in EduSage'})}); setToast(`Decision saved: ${d}`); const r=await fetch(API+`/applicants/${selected.id}`);setSelected(await r.json());load()};
 const navigate=n=>{setPage(n);setSelected(null);setMobile(false);window.scrollTo(0,0)};
 return <div className="app">
  <aside className={mobile?'mobileOpen':''}>
   <div className="brand"><div className="logo"><GraduationCap size={20}/></div><div><b>EduSage</b><span>Admissions OS</span></div></div>
   <div className="inst"><div><small>Workspace</small><b>Nexgile University</b></div><span>⌄</span></div>
   <div className="navLabel">WORKSPACE</div><nav>{nav.map(([n,I])=><button className={page===n&&!selected?'active':''} onClick={()=>navigate(n)} key={n}><I size={17}/>{n}</button>)}</nav>
   <div className="sideBottom"><button><Bell size={16}/>Notifications <em>3</em></button><div className="profile"><div className="avatar dark">AD</div><div><b>Admissions Admin</b><small>Institution role</small></div><MoreHorizontal size={15}/></div></div>
  </aside>
  <main>
   <header><div className="mobileMenu" onClick={()=>setMobile(!mobile)}><Menu size={20}/></div><div><div className="crumb">EDUSAGE / {selected?'APPLICANT':page.toUpperCase()}</div><h1>{selected?selected.name:page}</h1></div><div className="headRight"><div className="globalSearch"><Search size={16}/><input placeholder="Search applicants, programs…" value={search} onChange={e=>doSearch(e.target.value)}/><kbd>⌘ K</kbd></div><div className="avatar">AD</div></div></header>
   <div className="systemStrip"><ShieldCheck size={14}/><span>Operational</span><i></i><span>Fall 2026 cycle</span><i></i><span>Last synced just now</span></div>
   {selected?<ApplicantDetail a={selected} back={()=>setSelected(null)} decision={decision}/>:page==='Overview'?<Dashboard data={data} apps={apps} open={openApplicant}/>:page==='Applicants'||page==='Applications'||page==='Review & Decisions'?<Applicants apps={apps} open={openApplicant} mode={page}/>:page==='Events'?<Events/>:<Analytics/>}
  </main>
  {toast&&<div className="toast"><CheckCircle2 size={17}/>{toast}</div>}<div className="chat"><MessageCircle size={21}/><span>Help</span></div>
 </div>
}

function Dashboard({data,apps,open}){if(!data)return <Loading/>;return <section>
 <div className="heroBanner"><div><div className="eyebrow accent">ADMISSIONS OPERATING SYSTEM</div><h2>Clarity from application<br/><span>to enrollment.</span></h2><p>One workspace for applicant review, decisions, engagement and enrollment intelligence.</p></div><div className="heroMeta"><div><span>Cycle</span><b>Fall 2026</b></div><div><span>Workspace health</span><b><CircleDot size={11}/> Operational</b></div></div></div>
 <div className="cards"><Card title="Total applicants" value={data.totalApplicants} trend="+12.4%" sub="vs last term"/><Card title="Submitted" value={data.submitted} trend="+8.1%" sub="completion"/><Card title="Under review" value={data.underReview} trend="3" sub="assigned to you"/><Card title="Admitted" value={data.admitted} trend={data.yieldRate+'%'} sub="current yield"/></div>
 <div className="grid2"><div className="panel"><div className="panelHead"><div><div className="sectionKicker">FUNNEL</div><h2>Application pipeline</h2><p>Where applicants are in the current cycle.</p></div><button className="ghost">Details <ChevronRight size={14}/></button></div><div className="funnel"><Funnel n="Inquiries" v="428" w="100%"/><Funnel n="Applications" v="83" w="78%"/><Funnel n="Submitted" v="71" w="65%"/><Funnel n="Admitted" v="37" w="43%"/></div></div>
 <div className="panel"><div className="panelHead"><div><div className="sectionKicker">ACTION QUEUE</div><h2>Needs attention</h2><p>Items that need an operator.</p></div><span className="countBadge">3</span></div><Task icon={<AlertCircle/>} title="Missing documents" text="3 applicants have incomplete checklists"/><Task icon={<Clock3/>} title="Reviews due" text="5 assignments are due today"/><Task icon={<Bell/>} title="Decision notices" text="8 admitted applicants await notice"/></div></div>
 <div className="panel tablePanel"><div className="panelHead"><div><div className="sectionKicker">LIVE ACTIVITY</div><h2>Recent applicants</h2><p>Latest changes across your applicant pool.</p></div><button className="ghost">View all <ChevronRight size={14}/></button></div><ApplicantTable apps={apps.slice(0,5)} open={open}/></div>
 </section>}
function Card({title,value,trend,sub}){return <div className="card"><span>{title}</span><strong>{value}</strong><small><b>{trend}</b> {sub}</small></div>}
function Funnel({n,v,w}){return <div className="frow"><div><b>{n}</b><span>{v}</span></div><div className="bar"><i style={{width:w}}/></div></div>}
function Task({icon,title,text}){return <div className="task"><div className="taskIcon">{icon}</div><div><b>{title}</b><p>{text}</p></div><ChevronRight size={16}/></div>}
function Applicants({apps,open,mode}){const label=mode==='Review & Decisions'?'Reviewer queue':mode==='Applications'?'Application workspace':'Applicant directory';return <section><div className="toolbar"><div><div className="sectionKicker">{mode.toUpperCase()}</div><h2>{label}</h2><p>{apps.length} records · searchable, filterable workspace</p></div><div className="actions"><button className="ghost"><Filter size={14}/> Filter</button><button className="primary"><Plus size={14}/> New application</button></div></div><div className="panel tablePanel"><ApplicantTable apps={apps} open={open}/></div></section>}
function ApplicantTable({apps,open}){return <table><thead><tr><th>Applicant</th><th>Program</th><th>Source</th><th>Score</th><th>Checklist</th><th>Status</th><th></th></tr></thead><tbody>{apps.map(a=><tr key={a.id} onClick={()=>open(a.id)}><td><div className="person"><div className="mini">{a.name.split(' ').map(x=>x[0]).join('')}</div><div><b>{a.name}</b><small>{a.email}</small></div></div></td><td>{a.program}<small>{a.term}</small></td><td>{a.source}</td><td><b>{a.score}</b><small>/ 100</small></td><td><div className="checkline">{a.documents}/{a.required}<span className="progress"><i style={{width:(a.documents/a.required*100)+'%'}}/></span></div></td><td><Status s={a.status}/></td><td><ChevronRight size={15}/></td></tr>)}</tbody></table>}
function Status({s}){return <span className={'status '+s.toLowerCase().replaceAll(' ','-')}>{s}</span>}
function ApplicantDetail({ a, back, decision }) {
  return (
    <section>
      <button className="back" onClick={back}>
        <ArrowLeft size={15} /> Back to applicant directory
      </button>

      <div className="detailGrid">
        <div>
          <div className="panel heroApplicant">
            <div className="bigAvatar">
              {a.name.split(" ").map((x) => x[0]).join("")}
            </div>

            <div className="heroApplicantInfo">
              <div className="eyebrow">
                APPLICANT #{String(a.id).padStart(5, "0")}
              </div>
              <h2>{a.name}</h2>
              <p>
                {a.email} · {a.city} · {a.program}
              </p>
              <Status s={a.status} />
            </div>

            <div className="heroScore">
              <span>Review score</span>
              <strong>{a.score}</strong>
              <small>/100</small>
            </div>
          </div>

          <div className="panel">
            <div className="panelHead">
              <div>
                <div className="sectionKicker">APPLICANT 360°</div>
                <h2>Holistic review context</h2>
                <p>
                  Academic, engagement and source signals in one view.
                </p>
              </div>
              <button className="ghost">
                <Download size={14} /> Export
              </button>
            </div>

            <div className="statGrid">
              <div>
                <small>Academic GPA</small>
                <b>{a.gpa}</b>
              </div>
              <div>
                <small>Review score</small>
                <b>{a.score}/100</b>
              </div>
              <div>
                <small>Lead source</small>
                <b>{a.source}</b>
              </div>
              <div>
                <small>Term</small>
                <b>{a.term}</b>
              </div>
            </div>

            <h3>Activities & context</h3>

            <div className="chips">
              {a.activities?.map((x) => (
                <span key={x}>{x}</span>
              ))}
            </div>
          </div>

          <div className="panel">
            <div className="panelHead">
              <div>
                <div className="sectionKicker">AUDIT TRAIL</div>
                <h2>Timeline</h2>
                <p>Traceable applicant activity and decisions.</p>
              </div>
              <ShieldCheck size={18} />
            </div>

            {a.timeline?.map((x, i) => (
              <div className="timeline" key={i}>
                <div className="dot" />
                <div>
                  <b>{x.event}</b>
                  <small>
                    {x.time} · {x.by}
                    {x.note ? ` · ${x.note}` : ""}
                  </small>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="panel">
            <div className="sectionKicker">REQUIREMENTS</div>
            <h2>Application checklist</h2>

            {a.checklist?.map((x) => (
              <div className="check" key={x.name}>
                <span className={x.done ? "done" : ""}>
                  {x.done ? <Check size={11} /> : <AlertCircle size={11} />}
                </span>
                {x.name}
                <small>{x.done ? "Complete" : "Missing"}</small>
              </div>
            ))}
          </div>

          <div className="panel decision">
            <div className="sectionKicker">REVIEW GATE</div>
            <h2>Human decision</h2>

            <div className="aiCallout">
              <div className="spark">
                <Sparkles size={15} />
              </div>
              <div>
                <b>AI-assisted review signal</b>
                <p>Score {a.score}% · High confidence</p>
              </div>
            </div>

            <div className="scorebar">
              <i style={{ width: `${a.score}%` }} />
            </div>

            <p className="muted">
              Recommendation is advisory. Reviewer can override, record
              rationale and preserve the audit trail.
            </p>

            <div className="decisionBtns">
              <button onClick={() => decision("Admit")}>
                <Check size={14} /> Admit
              </button>
              <button onClick={() => decision("Waitlist")}>
                Waitlist
              </button>
              <button onClick={() => decision("Deny")}>
                <X size={14} /> Deny
              </button>
              <button onClick={() => decision("Review")}>
                Keep in review
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Events(){const [events,setEvents]=useState([]);useEffect(()=>fetch(API+'/events').then(r=>r.json()).then(setEvents),[]);return <section><div className="toolbar"><div><div className="sectionKicker">RECRUITMENT</div><h2>Events & engagement</h2><p>Virtual and in-person applicant engagement.</p></div><button className="primary"><Plus size={14}/> Create event</button></div><div className="eventGrid">{events.map(e=><div className="panel event" key={e.id}><div className="eventTop"><span>{e.type}</span><CalendarDays size={17}/></div><h2>{e.name}</h2><p>{e.date}</p><div className="capacity"><span>{e.registered} registered</span><span>{e.capacity} capacity</span></div><div className="scorebar"><i style={{width:e.registered/e.capacity*100+'%'}}/></div><button className="ghost full">Manage event <ChevronRight size={14}/></button></div>)}</div></section>}
function Analytics(){const [a,setA]=useState(null);useEffect(()=>fetch(API+'/analytics').then(r=>r.json()).then(setA),[]);if(!a)return <Loading/>;return <section><div className="toolbar"><div><div className="sectionKicker">INTELLIGENCE</div><h2>Enrollment analytics</h2><p>Operational views for volume, conversion and program demand.</p></div><button className="ghost"><Download size={14}/> Export CSV</button></div><div className="cards"><Card title="Applications" value="83" trend="+16.2%" sub="YoY"/><Card title="Admit rate" value="44.6%" trend="37" sub="admits"/><Card title="Completion" value="86%" trend="+4.1%" sub="vs last cycle"/><Card title="Yield" value="71%" trend="+6.8%" sub="projected"/></div><div className="grid2"><div className="panel"><div className="sectionKicker">TREND</div><h2>Monthly applications</h2><div className="chart">{a.monthly.map(x=><div className="col" key={x.month}><div style={{height:x.applications/1.1+'px'}}><span>{x.applications}</span></div><small>{x.month}</small></div>)}</div></div><div className="panel"><div className="sectionKicker">PROGRAM MIX</div><h2>Applications by program</h2>{Object.entries(a.programs).map(([k,v])=><div className="analyticRow" key={k}><span>{k}</span><b>{v}</b></div>)}</div></div></section>}
function Loading(){return <div className="loading"><Sparkles size={18}/> Loading EduSage workspace…</div>}
createRoot(document.getElementById('root')).render(<App/>);
