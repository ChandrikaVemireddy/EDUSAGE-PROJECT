from database import Base, engine, SessionLocal
from models import Applicant, Application, AuditEvent, Event

Base.metadata.create_all(bind=engine)
db = SessionLocal()
try:
    if db.query(Applicant).count() == 0:
        records = [
            ('Aarav Sharma','aarav@example.com','M.Tech Computer Science','Fall 2026','Under Review',86,8.8,'Website','Bengaluru',4,5,'Hackathon finalist|Student mentor|Research assistant'),
            ('Diya Reddy','diya@example.com','M.Sc Data Science','Fall 2026','Admitted',92,9.2,'Education Fair','Hyderabad',5,5,'Data science club|Research assistant|Volunteer'),
            ('Kabir Mehta','kabir@example.com','MBA','Fall 2026','Missing Documents',74,7.9,'Referral','Mumbai',3,5,'Entrepreneurship cell|Case competition'),
            ('Ananya Rao','ananya@example.com','M.Tech Computer Science','Spring 2027','Submitted',81,8.5,'LinkedIn','Chennai',5,5,'Coding club|Open source contributor'),
            ('Vikram Singh','vikram@example.com','BBA','Fall 2026','Waitlisted',78,8.1,'Google Campaign','Delhi',5,5,'Business club|Student ambassador'),
        ]
        for i, r in enumerate(records, 1):
            a = Applicant(name=r[0], email=r[1], program=r[2], term=r[3], status=r[4], score=r[5], gpa=r[6], source=r[7], city=r[8], documents=r[9], required=r[10], activities=r[11])
            db.add(a); db.flush()
            db.add(Application(applicant_id=a.id, application_no=f'EDU-2026-{i:04d}', submitted=True, fee_status='Paid'))
            db.add(AuditEvent(applicant_id=a.id, time='Today 10:42 AM', event='Application submitted', by='Applicant'))
            db.add(AuditEvent(applicant_id=a.id, time='Today 11:05 AM', event='Transcript matched', by='System'))
        for e in [
            ('M.Tech Information Session','Virtual','2026-09-18',100,74),
            ('Campus Open Day','In-person','2026-09-24',250,219),
            ('International Applicant Webinar','Virtual','2026-10-02',150,93),
        ]: db.add(Event(name=e[0], type=e[1], date=e[2], capacity=e[3], registered=e[4]))
        db.commit()
finally: db.close()
