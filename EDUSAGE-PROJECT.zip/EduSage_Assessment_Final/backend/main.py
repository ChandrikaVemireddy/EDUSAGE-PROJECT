from datetime import datetime
from typing import Optional
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from database import Base, engine, get_db
from models import Applicant, Application, AuditEvent, Event

Base.metadata.create_all(bind=engine)
app = FastAPI(title='EduSage Admission & Enrollment Portal', version='1.0.0')
app.add_middleware(CORSMiddleware, allow_origins=['http://localhost:5173'], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])

class Decision(BaseModel):
    decision: str
    note: Optional[str] = ''

STATUS_MAP = {'Admit':'Admitted','Deny':'Denied','Waitlist':'Waitlisted','Review':'Under Review'}

def applicant_out(a):
    return {'id':a.id,'name':a.name,'email':a.email,'program':a.program,'term':a.term,'status':a.status,'score':a.score,'gpa':a.gpa,'source':a.source,'city':a.city,'documents':a.documents,'required':a.required}

@app.get('/api/health')
def health(): return {'status':'ok','service':'EduSage API','database':'SQLite'}

@app.get('/api/dashboard')
def dashboard(db: Session = Depends(get_db)):
    rows = db.query(Applicant).all(); total=len(rows)
    submitted=sum(a.status in ['Submitted','Under Review','Admitted','Waitlisted'] for a in rows)
    completion=round(sum((a.documents/a.required) if a.required else 0 for a in rows)/total*100) if total else 0
    return {'totalApplicants':total,'submitted':submitted,'underReview':sum(a.status=='Under Review' for a in rows),'admitted':sum(a.status=='Admitted' for a in rows),'waitlisted':sum(a.status=='Waitlisted' for a in rows),'completionRate':completion,'yieldRate':round(sum(a.status=='Admitted' for a in rows)/total*100) if total else 0}

@app.get('/api/applicants')
def get_applicants(q: str='', db: Session = Depends(get_db)):
    rows=db.query(Applicant).order_by(Applicant.id).all(); q=q.lower().strip()
    if q: rows=[a for a in rows if any(q in str(getattr(a,k,'')).lower() for k in ['name','email','program','status','source','city','term'])]
    return [applicant_out(a) for a in rows]

@app.get('/api/applicants/{applicant_id}')
def get_applicant(applicant_id:int, db: Session = Depends(get_db)):
    a=db.get(Applicant, applicant_id)
    if not a: raise HTTPException(404,'Applicant not found')
    checklist=[{'name':'Application Form','done':True},{'name':'Transcript','done':a.documents>=2},{'name':'Recommendation','done':a.documents>=3},{'name':'Test Score','done':a.documents>=4},{'name':'Portfolio','done':a.documents>=5}]
    return {**applicant_out(a),'application':{'number':a.applications[0].application_no if a.applications else 'N/A','feeStatus':a.applications[0].fee_status if a.applications else 'Pending'},'checklist':checklist,'timeline':[{'time':x.time,'event':x.event,'by':x.by,'note':x.note} for x in sorted(a.audit,key=lambda x:x.id)],'activities':a.activities.split('|') if a.activities else []}

@app.post('/api/applicants/{applicant_id}/decision')
def make_decision(applicant_id:int, body:Decision, db: Session = Depends(get_db)):
    a=db.get(Applicant, applicant_id)
    if not a: raise HTTPException(404,'Applicant not found')
    if body.decision not in STATUS_MAP: raise HTTPException(400,'Invalid decision')
    a.status=STATUS_MAP[body.decision]
    db.add(AuditEvent(applicant_id=a.id,time=datetime.now().strftime('%Y-%m-%d %H:%M'),event=f'Decision: {body.decision}',by='Reviewer',note=body.note or 'Human reviewer decision'))
    db.commit(); db.refresh(a); return applicant_out(a)

@app.get('/api/events')
def get_events(db: Session = Depends(get_db)):
    return [{'id':e.id,'name':e.name,'type':e.type,'date':e.date,'capacity':e.capacity,'registered':e.registered} for e in db.query(Event).all()]

@app.get('/api/analytics')
def analytics(db: Session = Depends(get_db)):
    rows=db.query(Applicant).all(); statuses={}; programs={}; sources={}
    for a in rows:
        statuses[a.status]=statuses.get(a.status,0)+1; programs[a.program]=programs.get(a.program,0)+1; sources[a.source]=sources.get(a.source,0)+1
    monthly=[{'month':'May','applications':32,'admitted':12},{'month':'Jun','applications':45,'admitted':18},{'month':'Jul','applications':58,'admitted':25},{'month':'Aug','applications':71,'admitted':31},{'month':'Sep','applications':83,'admitted':37}]
    return {'statuses':statuses,'programs':programs,'sources':sources,'monthly':monthly}
