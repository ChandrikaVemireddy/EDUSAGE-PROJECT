from sqlalchemy import Column, Integer, String, Float, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
from database import Base

class Applicant(Base):
    __tablename__ = 'applicants'
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    email = Column(String(160), nullable=False, unique=True)
    program = Column(String(120), nullable=False)
    term = Column(String(40), nullable=False)
    status = Column(String(50), nullable=False, default='Submitted')
    score = Column(Integer, default=0)
    gpa = Column(Float, default=0)
    source = Column(String(80), default='Website')
    city = Column(String(80), default='')
    documents = Column(Integer, default=0)
    required = Column(Integer, default=5)
    activities = Column(String(500), default='')
    applications = relationship('Application', back_populates='applicant', cascade='all, delete-orphan')
    audit = relationship('AuditEvent', back_populates='applicant', cascade='all, delete-orphan')

class Application(Base):
    __tablename__ = 'applications'
    id = Column(Integer, primary_key=True)
    applicant_id = Column(Integer, ForeignKey('applicants.id'), nullable=False)
    application_no = Column(String(40), unique=True, nullable=False)
    submitted = Column(Boolean, default=True)
    fee_status = Column(String(30), default='Paid')
    applicant = relationship('Applicant', back_populates='applications')

class AuditEvent(Base):
    __tablename__ = 'audit_events'
    id = Column(Integer, primary_key=True)
    applicant_id = Column(Integer, ForeignKey('applicants.id'), nullable=False)
    time = Column(String(50), nullable=False)
    event = Column(String(180), nullable=False)
    by = Column(String(80), nullable=False)
    note = Column(Text, default='')
    applicant = relationship('Applicant', back_populates='audit')

class Event(Base):
    __tablename__ = 'events'
    id = Column(Integer, primary_key=True)
    name = Column(String(160), nullable=False)
    type = Column(String(40), nullable=False)
    date = Column(String(30), nullable=False)
    capacity = Column(Integer, default=0)
    registered = Column(Integer, default=0)
