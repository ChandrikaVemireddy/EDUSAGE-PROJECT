# EduSage — Admission & Enrollment Portal

Professional full-stack assessment application based on the supplied Nexgile EduSage functional requirements.

## Stack
- Frontend: React + Vite + Lucide React
- Backend: Python + FastAPI
- Database: SQLite
- ORM: SQLAlchemy
- API: REST

## Run locally

### 1. Backend
```bash
cd backend
python -m venv venv
# Windows
venv\\Scripts\\activate
# macOS/Linux
# source venv/bin/activate
pip install -r requirements.txt
python seed.py
uvicorn main:app --reload --port 8000
```

Backend: http://localhost:8000  
API docs: http://localhost:8000/docs

### 2. Frontend
Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```

Frontend: http://localhost:5173

## Demo flow
Dashboard → Applicant Directory → Applicant 360° → Checklist → AI-assisted review signal → Human decision → Audit timeline → Analytics / Events.

## Assessment scope
The supplied requirements describe a broad enterprise admission platform. This implementation prioritizes the strongest demonstrable end-to-end workflow while keeping the architecture ready for future SIS, transcript-provider, payment, communication, and other integrations.
